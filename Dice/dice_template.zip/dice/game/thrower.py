import random

# TODO: Define the Thrower class here.